function enviar() {

    alert("Um link foi enviado para seu e-mail, acesse ele e redefina sua senha.")
    
}